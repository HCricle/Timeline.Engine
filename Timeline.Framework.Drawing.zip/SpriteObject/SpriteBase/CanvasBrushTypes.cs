﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Timeline.Framework.SpriteObject
{
    public enum CanvasBrushTypes
    {
        SolidColorBrush,//纯颜色
        RadialGradientBrush,//严肃点
        LinearGradientBrush//线性颜色
    }
}
